namespace ECommerce.Features.Products
{
  public class CreateProductVariantViewModel
  {
    public string Colour { get; set; }
    public string Storage { get; set; }
    public decimal Price { get; set; }
  }
}
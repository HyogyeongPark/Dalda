namespace ECommerce.Features.Products
{
  public class ValidateProductViewModel
  {
    public string Name { get; set; }
  }
}
namespace ECommerce.Features.Orders
{
  public class OrderItemViewModel
  {
    public int ProductId { get; set; }
    public int ColourId { get; set; }
    public int StorageId { get; set; }
    public int Quantity { get; set; }
  }
}
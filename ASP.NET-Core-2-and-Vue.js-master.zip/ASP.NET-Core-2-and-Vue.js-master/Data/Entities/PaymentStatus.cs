namespace ECommerce.Data.Entities
{
  public enum PaymentStatus
  {
    Pending,
    Paid,
    Declined
  }
}
﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace ECommerce.Data.Migrations
{
  public partial class Catalogue : Migration
  {
    protected override void Up(MigrationBuilder migrationBuilder)
    {
      migrationBuilder.RenameColumn(
          name: "Price",
          table: "Products",
          newName: "TalkTime");

      migrationBuilder.AddColumn<int>(
          name: "BrandId",
          table: "Products",
          nullable: false,
          defaultValue: 0);

      migrationBuilder.AddColumn<int>(
          name: "OSId",
          table: "Products",
          nullable: false,
          defaultValue: 0);

      migrationBuilder.AddColumn<decimal>(
          name: "ScreenSize",
          table: "Products",
          nullable: false,
          defaultValue: 0m);

      migrationBuilder.AddColumn<decimal>(
          name: "StandbyTime",
          table: "Products",
          nullable: false,
          defaultValue: 0m);

      migrationBuilder.CreateTable(
          name: "Brands",
          columns: table => new
          {
            Id = table.Column<int>(nullable: false)
                  .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn)
                  .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
            Name = table.Column<string>(nullable: false)
          },
          constraints: table =>
          {
            table.PrimaryKey("PK_Brands", x => x.Id);
          });

      migrationBuilder.CreateTable(
          name: "Colours",
          columns: table => new
          {
            Id = table.Column<int>(nullable: false)
                  .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn)
                  .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
            Name = table.Column<string>(nullable: false)
          },
          constraints: table =>
          {
            table.PrimaryKey("PK_Colours", x => x.Id);
          });

      migrationBuilder.CreateTable(
          name: "Features",
          columns: table => new
          {
            Id = table.Column<int>(nullable: false)
                  .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
            Name = table.Column<string>(nullable: false)
          },
          constraints: table =>
          {
            table.PrimaryKey("PK_Features", x => x.Id);
          });

      migrationBuilder.CreateTable(
          name: "Images",
          columns: table => new
          {
            Id = table.Column<int>(nullable: false)
                  .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
            ProductId = table.Column<int>(nullable: false),
            Url = table.Column<string>(nullable: false)
          },
          constraints: table =>
          {
            table.PrimaryKey("PK_Images", x => x.Id);
            table.ForeignKey(
                      name: "FK_Images_Products_ProductId",
                      column: x => x.ProductId,
                      principalTable: "Products",
                      principalColumn: "Id",
                      onDelete: ReferentialAction.Cascade);
          });

      migrationBuilder.CreateTable(
          name: "OS",
          columns: table => new
          {
            Id = table.Column<int>(nullable: false)
                  .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
            Name = table.Column<string>(nullable: false)
          },
          constraints: table =>
          {
            table.PrimaryKey("PK_OS", x => x.Id);
          });

      migrationBuilder.CreateTable(
          name: "Storage",
          columns: table => new
          {
            Id = table.Column<int>(nullable: false)
                  .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
            Capacity = table.Column<int>(nullable: false)
          },
          constraints: table =>
          {
            table.PrimaryKey("PK_Storage", x => x.Id);
          });

      migrationBuilder.CreateTable(
          name: "ProductFeatures",
          columns: table => new
          {
            ProductId = table.Column<int>(nullable: false),
            FeatureId = table.Column<int>(nullable: false)
          },
          constraints: table =>
          {
            table.PrimaryKey("PK_ProductFeatures", x => new { x.ProductId, x.FeatureId });
            table.ForeignKey(
                      name: "FK_ProductFeatures_Features_FeatureId",
                      column: x => x.FeatureId,
                      principalTable: "Features",
                      principalColumn: "Id",
                      onDelete: ReferentialAction.Cascade);
            table.ForeignKey(
                      name: "FK_ProductFeatures_Products_ProductId",
                      column: x => x.ProductId,
                      principalTable: "Products",
                      principalColumn: "Id",
                      onDelete: ReferentialAction.Cascade);
          });

      migrationBuilder.CreateTable(
          name: "ProductVariants",
          columns: table => new
          {
            ProductId = table.Column<int>(nullable: false),
            ColourId = table.Column<int>(nullable: false),
            StorageId = table.Column<int>(nullable: false),
            Price = table.Column<decimal>(nullable: false)
          },
          constraints: table =>
          {
            table.PrimaryKey("PK_ProductVariants", x => new { x.ProductId, x.ColourId, x.StorageId });
            table.ForeignKey(
                      name: "FK_ProductVariants_Colours_ColourId",
                      column: x => x.ColourId,
                      principalTable: "Colours",
                      principalColumn: "Id",
                      onDelete: ReferentialAction.Cascade);
            table.ForeignKey(
                      name: "FK_ProductVariants_Products_ProductId",
                      column: x => x.ProductId,
                      principalTable: "Products",
                      principalColumn: "Id",
                      onDelete: ReferentialAction.Cascade);
            table.ForeignKey(
                      name: "FK_ProductVariants_Storage_StorageId",
                      column: x => x.StorageId,
                      principalTable: "Storage",
                      principalColumn: "Id",
                      onDelete: ReferentialAction.Cascade);
          });

      migrationBuilder.CreateIndex(
          name: "IX_Products_BrandId",
          table: "Products",
          column: "BrandId");

      migrationBuilder.CreateIndex(
          name: "IX_Products_OSId",
          table: "Products",
          column: "OSId");

      migrationBuilder.CreateIndex(
          name: "IX_Images_ProductId",
          table: "Images",
          column: "ProductId");

      migrationBuilder.CreateIndex(
          name: "IX_ProductFeatures_FeatureId",
          table: "ProductFeatures",
          column: "FeatureId");

      migrationBuilder.CreateIndex(
          name: "IX_ProductVariants_ColourId",
          table: "ProductVariants",
          column: "ColourId");

      migrationBuilder.CreateIndex(
          name: "IX_ProductVariants_StorageId",
          table: "ProductVariants",
          column: "StorageId");

      migrationBuilder.AddForeignKey(
          name: "FK_Products_Brands_BrandId",
          table: "Products",
          column: "BrandId",
          principalTable: "Brands",
          principalColumn: "Id",
          onDelete: ReferentialAction.Cascade);

      migrationBuilder.AddForeignKey(
          name: "FK_Products_OS_OSId",
          table: "Products",
          column: "OSId",
          principalTable: "OS",
          principalColumn: "Id",
          onDelete: ReferentialAction.Cascade);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
      migrationBuilder.DropForeignKey(
          name: "FK_Products_Brands_BrandId",
          table: "Products");

      migrationBuilder.DropForeignKey(
          name: "FK_Products_OS_OSId",
          table: "Products");

      migrationBuilder.DropTable(
          name: "Brands");

      migrationBuilder.DropTable(
          name: "Images");

      migrationBuilder.DropTable(
          name: "OS");

      migrationBuilder.DropTable(
          name: "ProductFeatures");

      migrationBuilder.DropTable(
          name: "ProductVariants");

      migrationBuilder.DropTable(
          name: "Features");

      migrationBuilder.DropTable(
          name: "Colours");

      migrationBuilder.DropTable(
          name: "Storage");

      migrationBuilder.DropIndex(
          name: "IX_Products_BrandId",
          table: "Products");

      migrationBuilder.DropIndex(
          name: "IX_Products_OSId",
          table: "Products");

      migrationBuilder.DropColumn(
          name: "BrandId",
          table: "Products");

      migrationBuilder.DropColumn(
          name: "OSId",
          table: "Products");

      migrationBuilder.DropColumn(
          name: "ScreenSize",
          table: "Products");

      migrationBuilder.DropColumn(
          name: "StandbyTime",
          table: "Products");

      migrationBuilder.RenameColumn(
          name: "TalkTime",
          table: "Products",
          newName: "Price");
    }
  }
}
